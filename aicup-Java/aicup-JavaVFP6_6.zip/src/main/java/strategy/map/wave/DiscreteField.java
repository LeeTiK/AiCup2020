package strategy.map.wave;

public class DiscreteField {

    int district;
    int market;
    int lastTickUpdate;
}


