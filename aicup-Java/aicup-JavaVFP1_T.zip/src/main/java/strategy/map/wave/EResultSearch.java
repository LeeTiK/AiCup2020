package strategy.map.wave;

public enum EResultSearch {
    BLOCK,
    PATH,
    SUCCES,
}
