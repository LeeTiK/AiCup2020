package strategy.war;

public enum ETroopUnit {
    SIMPLE;
}
