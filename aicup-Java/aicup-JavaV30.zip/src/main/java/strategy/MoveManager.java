package strategy;

// класс помогающий юнитам двигаться по собственому алгоритму поиска пути
public class MoveManager {



}
