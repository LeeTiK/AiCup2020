package strategy;

import model.*;
import strategy.map.potfield.DodgePositionAnswer;

import java.util.ArrayList;
import java.util.HashMap;

public class DodgeManager {

    GlobalManager mGlobalManager;

    public DodgeManager(){

    }


    public void update(GlobalManager globalManager,HashMap<Integer, EntityAction> actionHashMap) {
        MyPlayer myPlayer = globalManager.getGlobalStatistic().getMyPlayer();

        ArrayList<MyEntity> builderUnitArrayList = myPlayer.getEntityArrayList(EntityType.BUILDER_UNIT);

        for (int i = 0; i < builderUnitArrayList.size(); i++) {
            MyEntity builderUnit = builderUnitArrayList.get(i);

            MoveAction m = null;
            BuildAction b = null;
            AttackAction a = null;
            RepairAction r = null;

            EntityAction entityAction = actionHashMap.get(builderUnit.getId());
            if (entityAction == null) entityAction = new EntityAction(null, null, null, null);

            ArrayList<MyEntity> resource = globalManager.getGlobalMap().getEntityMap(builderUnit.getPosition(),GlobalMap.aroundArray,FinalConstant.getMyID(),-1,false,EntityType.RESOURCE);

            // увороты от всех по ПП
            DodgePositionAnswer dodgePositionAnswer = globalManager.getMapPotField().getDodgePositionBuild(builderUnit,resource.size()>0,false);

            if (dodgePositionAnswer != null) {

                builderUnit.setDodge(true);
                builderUnit.setUpdate(true);
                builderUnit.setDodgePositionAnswer(dodgePositionAnswer);

                myPlayer.addCountBuildDodge();

                myPlayer.getUnitDodgeArrayList().add(builderUnit);

                actionHashMap.put(builderUnit.getId(), entityAction);
            }
        }
    }
}
