package strategy;

import java.util.ArrayList;

public class MyGroupUnit extends MyEntity {

    ArrayList<MyEntity> mMyEntityArrayList;

    public MyGroupUnit() {
        super();
        mMyEntityArrayList = new ArrayList<>();
    }


}
