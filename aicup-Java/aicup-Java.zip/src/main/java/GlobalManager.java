import model.Action;
import model.Entity;
import model.PlayerView;

import java.util.ArrayList;
import java.util.HashMap;

public class GlobalManager {
    // менеджер отвечает за экономическую состовляющую
    EconomicManager mEconomicManager;
    // менеджер отвечающий за бой / защиту
    WarManager mWarManager;


    // количество от
    GlobalStatistic mGlobalStatistic;



    public GlobalManager(){
        mEconomicManager = new EconomicManager();
        mWarManager = new WarManager();
        mGlobalStatistic = new GlobalStatistic();
    }


    public Action update(PlayerView playerView, DebugInterface debugInterface){
        // глобальная статистика и информация о мире
        mGlobalStatistic.updateInfo(playerView,debugInterface);

        /////////////////////////////////////////////////////

        Action action = mEconomicManager.update(playerView,mGlobalStatistic);



        return  new Action(new HashMap<>());
    }
}
