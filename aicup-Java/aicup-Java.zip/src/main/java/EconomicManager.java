import model.*;

import java.io.File;
import java.util.ArrayList;

public class EconomicManager {

    // количество рабочих
    int sizeBuildUnit;
    // количество золота
    int sizeGold;

    public EconomicManager(){

    }

    public Action update(PlayerView playerView, GlobalStatistic globalStatistic){
         updateInfo(playerView);

         MyPlayer myPlayer = globalStatistic.getMyPlayer();

         ArrayList<MyEntity> arrayList = myPlayer.getEntityArrayList(EntityType.BUILDER_UNIT);

         EntityAction entityAction = new EntityAction();



         return new Action();
    }

    private void updateInfo(PlayerView playerView){
        Player player = Final.getMyPlayer(playerView);
        sizeGold = player.getResource();


    }
}
