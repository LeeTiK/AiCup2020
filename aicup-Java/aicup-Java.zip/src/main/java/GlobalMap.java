public class GlobalMap {
    // класс карты
}
