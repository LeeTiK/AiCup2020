package strategy.map.dijkstra;

public class Dijkstra {

    public Dijkstra() {

    }


}
