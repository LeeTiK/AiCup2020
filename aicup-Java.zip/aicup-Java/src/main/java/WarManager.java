public class WarManager {
}
