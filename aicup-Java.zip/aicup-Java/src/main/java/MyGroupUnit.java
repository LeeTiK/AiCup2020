import model.Entity;

import java.util.ArrayList;

public class MyGroupUnit extends MyUnit {

    ArrayList<MyUnit> mMyUnitArrayList;

    public MyGroupUnit() {
        super();
        mMyUnitArrayList = new ArrayList<>();
    }
}
