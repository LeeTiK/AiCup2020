import model.EntityType;
import model.PlayerView;

import java.util.ArrayList;

public class GlobalStatistic {

    final static String TAG = "GlobalStatistic";

    ArrayList<MyPlayer> mMyPlayers;

    int myID=0;

    static int currentTik = 0;

    public GlobalStatistic(){
        mMyPlayers = new ArrayList<>();
    }


    public void updateInfo(PlayerView playerView, DebugInterface debugInterface){
        myID = playerView.getMyId();

        updatePlayerInfo(playerView);

    }

    private void updatePlayerInfo(PlayerView playerView){

        currentTik = playerView.getCurrentTick();
        Final.DEBUG(TAG,"CurrentTik: " + currentTik);

      //  playerView.isFogOfWar()

        // добавление и обновление информации о игроках
        for (int i=0; i<playerView.getPlayers().length; i++)
        {
            boolean check =true;
            for (int j=0; j<mMyPlayers.size(); j++)
            {
                if (playerView.getPlayers()[i].getId() == mMyPlayers.get(j).getId())
                {
                    mMyPlayers.get(j).update(playerView.getPlayers()[i]);
                    check = false;
                    break;
                }
            }

            if (check)
            {
                mMyPlayers.add(new MyPlayer(playerView.getPlayers()[i]));
            }
        }
        //
        for (int j=0; j<mMyPlayers.size(); j++)
        {
            mMyPlayers.get(j).startUpdate();
        }

        // добавление и обновление информации о юнитах
        for (int i=0; i<playerView.getEntities().length; i++)
        {
            if (playerView.getEntities()[i].getPlayerId() == null) continue;

            MyPlayer myPlayer = getPlayer(playerView.getEntities()[i].getPlayerId());

            if (myPlayer == null) continue;

            EStatus eStatus = myPlayer.updateEntity(playerView.getEntities()[i]);

            switch (eStatus)
            {
                case NEW_Entity:
                case DELETE_Entity: {
                    Final.DEBUG(TAG, "Player ID: " + myPlayer.getId() + " Event: " + eStatus + " Type: " + playerView.getEntities()[i].getEntityType());
                    break;
                }

                case UPDATE_Entity:
                    {
                        break;
                    }
                case ERROR:{
                    Final.DEBUG(TAG,"Player ID: " +myPlayer.getId() + " Event: " + eStatus);
                    break;
                }
            }
        }

        for (int j=0; j<mMyPlayers.size(); j++)
        {
            EntityType entityType = mMyPlayers.get(j).checkDelete();

            if (entityType!=null){
                Final.DEBUG(TAG,"Player ID: " +mMyPlayers.get(j).getId() + " Event: " + EStatus.DELETE_Entity + " Type: " + entityType);
            }

            while (entityType!=null)
            {
                entityType = mMyPlayers.get(j).checkDelete();

                if (entityType!=null){
                    Final.DEBUG(TAG,"Player ID: " +mMyPlayers.get(j).getId() + " Event: " + EStatus.DELETE_Entity + " Type: " + entityType);
                }
            }
        }


    }


    public MyPlayer getMyPlayer(){
        return getPlayer(myID);
    }

    public MyPlayer getPlayer(int id)
    {
        for (int i=0; i<mMyPlayers.size(); i++)
        {
            if (mMyPlayers.get(i).getId() == id) return mMyPlayers.get(i);
        }

        return null;
    }

}
