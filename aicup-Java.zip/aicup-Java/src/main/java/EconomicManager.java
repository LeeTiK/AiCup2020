import model.Action;
import model.Player;
import model.PlayerView;

import java.io.File;

public class EconomicManager {

    // количество рабочих
    int sizeBuildUnit;
    // количество золота
    int sizeGold;

    public EconomicManager(){

    }

    public Action update(PlayerView playerView, GlobalStatistic globalStatistic){
         updateInfo(playerView);



         return new Action();
    }

    private void updateInfo(PlayerView playerView){
        Player player = Final.getMyPlayer(playerView);
        sizeGold = player.getResource();


    }
}
